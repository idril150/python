def sum(a,b):
    print(f"el resultado de la suma es: {a+b}")

def res(a,b):
    print(f"el resultado de la resta es: {a-b}")

def mul(a,b):
    print(f"el resultado de la multiplicacion es: {a*b}")

def div(a,b):
    print(f"el resultado de la division es: {a/b}")
    
def expo(a,b):
    print(f"el resultado de la operacion es {a**b}")

def redon(a):
    print(f"el valor redondeado de {a} es: {round(a)}")

