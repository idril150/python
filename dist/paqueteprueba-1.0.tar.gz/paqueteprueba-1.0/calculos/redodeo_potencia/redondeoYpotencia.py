def expo(a,b):
    print(f"el resultado de la operacion es {a**b}")

def redon(a):
    print(f"el valor redondeado de {a} es: {round(a)}")

