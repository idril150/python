from setuptools import setup
setup(
    name="paqueteprueba",
    version="1.0",
    description="Paquete de redondeo y potencias",
    author="Victor Munoz Rodas",
    author_email="ebibari1@gmail.com",
    packages=["calculos","calculos.redodeo_potencia"]
)